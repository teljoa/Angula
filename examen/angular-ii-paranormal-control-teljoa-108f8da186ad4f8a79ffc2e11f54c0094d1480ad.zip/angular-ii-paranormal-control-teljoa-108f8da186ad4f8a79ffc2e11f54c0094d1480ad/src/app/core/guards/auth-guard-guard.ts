import { CanActivateFn, Router } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  // TODO: Implementar lógica para verificar si el usuario está autenticado
  // - Si el usuario no está autenticado, redirigir a la página de login
  // - Si el usuario está autenticado, permitir acceso a la ruta solicitada
  return false;
};