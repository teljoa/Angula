import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // TODO: Implementar servicio de autenticación con métodos para login, logout y verificación de estado de autenticación
}