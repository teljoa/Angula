import { HttpInterceptorFn } from '@angular/common/http';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
 
  // TODO: Implementar lógica para agregar el token de autenticación a las solicitudes HTTP

  return next(req);
};