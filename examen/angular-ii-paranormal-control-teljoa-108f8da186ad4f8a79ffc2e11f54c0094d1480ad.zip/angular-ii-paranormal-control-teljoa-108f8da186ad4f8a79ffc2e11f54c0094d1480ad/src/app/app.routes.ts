// app.routes.ts
import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth-guard-guard';
import { Anomalies } from './features/anomalies/anomaliy-list/anomalies';

export const routes: Routes = [
  // TODO: Cargar rutas de autenticación (login, register) sin protección de guardia
  // La ruta de login se cargará siempre, la de register solo si el usuario navega a ella (lazy loading)
  
  // El resto de rutas estarán protegidas por el authGuard, que redirigirá a login si no hay usuario autenticado
  // Todas las rutas relacionadas con anomalías se cargarán de forma perezosa (lazy loading) para optimizar la carga inicial de la aplicación
  // Las rutas de dashboard y equipamiento como se quiera:
  // dashboard
  // anomalies - list
  // anomalies/create - form para crear nueva anomalía
  // anomalies/edit/:id - form para editar anomalía existente
  // equipment - listado de equipamiento
  // equipment/add - form para agregar nuevo equipamiento
  // Si no se encuentra la ruta, redirigir a login
];